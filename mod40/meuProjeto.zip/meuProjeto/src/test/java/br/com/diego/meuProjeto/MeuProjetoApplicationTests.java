package br.com.diego.meuProjeto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeuProjetoApplicationTests {

	@Test
	void contextLoads() {
	}

}
