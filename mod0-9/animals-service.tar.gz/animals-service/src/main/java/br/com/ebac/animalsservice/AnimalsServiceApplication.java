package br.com.ebac.animalsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnimalsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnimalsServiceApplication.class, args);
	}

}
